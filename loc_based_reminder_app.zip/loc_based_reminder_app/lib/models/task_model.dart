class TaskModel {
  final String id;
  final String title;
  final String description;
  final String date;
  final String time;
  final String label;
  final Map<String, double>? location; // lat/lng
  final String userId;
  final String status;
  final String? notificationTime24h;

  TaskModel({
    required this.id,
    required this.title,
    required this.description,
    required this.date,
    required this.time,
    required this.label,
    required this.userId,
    required this.status,
    this.location,
    this.notificationTime24h,
  });

  factory TaskModel.fromMap(Map<String, dynamic> map, String id) {
    return TaskModel(
      id: id,
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      date: map['date'] ?? '',
      time: map['time'] ?? '',
      label: map['label'] ?? '',
      location: map['location'] != null ? Map<String, double>.from(map['location']) : null,
      userId: map['userId'] ?? '',
      status: map['status'] ?? 'To Do',
      notificationTime24h: map['notificationTime24h'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'date': date,
      'time': time,
      'label': label,
      'location': location,
      'userId': userId,
      'status': status,
      'notificationTime24h': notificationTime24h,
    };
  }
} 