import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../models/user_model.dart';
import '../../views/homescreen/aqi_service.dart';
import '../../views/homescreen/weather_service.dart';
import '../../models/task_model.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../main.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest_all.dart' as tz;

class UserProvider extends ChangeNotifier {
  UserModel? _user;
  bool _isLoaded = false;

  String? _profileImageBase64;

  String? get profileImageBase64 => _profileImageBase64;

  UserModel? get user => _user;
  bool get isLoaded => _isLoaded;

  Future<void> fetchUser() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;
    final doc = await FirebaseFirestore.instance.collection('users').doc(currentUser.uid).get();
    if (doc.exists) {
      _user = UserModel.fromMap(doc.data()!);
      _isLoaded = true;
      notifyListeners();
    }
  }

  void setUser(UserModel user) {
    _user = user;
    _isLoaded = true;
    notifyListeners();
  }

  void clear() {
    _user = null;
    _isLoaded = false;
    _profileImageBase64 = null;
    notifyListeners();
  }

  Future<void> updateCurrentLocation() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return;
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) return;
      }
      if (permission == LocationPermission.deniedForever) return;
      final position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      await FirebaseFirestore.instance.collection('users').doc(currentUser.uid).update({
        'currentLocation': {
          'lat': position.latitude,
          'lng': position.longitude,
        }
      });
    } catch (e) {
      // Optionally handle error
    }
  }

  Future<void> loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    _profileImageBase64 = prefs.getString('profile_image');
    notifyListeners();
  }

  void setProfileImage(String? base64) {
    _profileImageBase64 = base64;
    notifyListeners();
  }

  void clearProfileImage() {
    _profileImageBase64 = null;
    notifyListeners();
  }
}

class AQIProvider extends ChangeNotifier {
  String? _aqi;
  bool _isLoaded = false;

  String? get aqi => _aqi;
  bool get isLoaded => _isLoaded;

  Future<void> fetchAQI() async {
    try {
      final aqiData = await AQIService().fetchAQI();
      _aqi = aqiData;
      _isLoaded = true;
      notifyListeners();
    } catch (e) {
      _aqi = null;
      _isLoaded = false;
      notifyListeners();
    }
  }
}

class TrafficProvider extends ChangeNotifier {
  String? _trafficUpdate;
  bool _isLoaded = false;

  String? get trafficUpdate => _trafficUpdate;
  bool get isLoaded => _isLoaded;

  Future<void> fetchTraffic() async {
    // Placeholder: Replace with real API call
    await Future.delayed(const Duration(milliseconds: 500));
    _trafficUpdate = "Smooth"; // Example value
    _isLoaded = true;
    notifyListeners();
  }
}

class WeatherProvider extends ChangeNotifier {
  Map<String, dynamic>? _weather;
  bool _isLoaded = false;

  Map<String, dynamic>? get weather => _weather;
  bool get isLoaded => _isLoaded;

  Future<void> fetchWeather() async {
    try {
      final weatherData = await WeatherService().fetchWeather();
      _weather = weatherData;
      _isLoaded = true;
      notifyListeners();
    } catch (e) {
      _weather = null;
      _isLoaded = false;
      notifyListeners();
    }
  }
}

class TaskProvider extends ChangeNotifier {
  List<TaskModel> _tasks = [];
  bool _isLoaded = false;

  List<TaskModel> get tasks => _tasks;
  bool get isLoaded => _isLoaded;

  Future<void> fetchTasks() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    final snapshot = await FirebaseFirestore.instance
        .collection('tasks')
        .where('userId', isEqualTo: user.uid)
        .get();
    _tasks = snapshot.docs
        .map((doc) => TaskModel.fromMap(doc.data(), doc.id))
        .toList();
    // Check for overdue tasks
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    for (int i = 0; i < _tasks.length; i++) {
      final task = _tasks[i];
      if (task.status != 'Completed' && task.status != 'Overdue') {
        final taskDate = DateTime.tryParse(task.date);
        if (taskDate != null && taskDate.isBefore(today)) {
          await FirebaseFirestore.instance.collection('tasks').doc(task.id).update({'status': 'Overdue'});
          _tasks[i] = TaskModel(
            id: task.id,
            title: task.title,
            description: task.description,
            date: task.date,
            time: task.time,
            label: task.label,
            userId: task.userId,
            status: 'Overdue',
            location: task.location,
          );
        }
      }
    }
    _isLoaded = true;
    notifyListeners();
  }

  Future<void> addTask(TaskModel task) async {
    final docRef = await FirebaseFirestore.instance.collection('tasks').add(task.toMap());
    final newTask = TaskModel(
      id: docRef.id,
      title: task.title,
      description: task.description,
      date: task.date,
      time: task.time,
      label: task.label,
      location: task.location,
      userId: task.userId,
      status: task.status,
    );
    _tasks.add(newTask);
    notifyListeners();

    // Schedule local notification
    await _scheduleTaskNotification(newTask);

    // Save notification info to Firestore for this user
    await FirebaseFirestore.instance
        .collection('users')
        .doc(task.userId)
        .collection('notifications')
        .add({
      'taskId': newTask.id,
      'title': newTask.title,
      'description': newTask.description,
      'date': newTask.date,
      'time': newTask.time,
      'createdAt': FieldValue.serverTimestamp(),
      'status': 'pending',
    });
  }

  Future<void> _scheduleTaskNotification(TaskModel task) async {
    try {
      final dateParts = task.date.split('-');
      final timeParts = task.time.split(":");
      if (dateParts.length != 3 || timeParts.length < 2) return;
      final year = int.parse(dateParts[0]);
      final month = int.parse(dateParts[1]);
      final day = int.parse(dateParts[2]);
      final hour = int.parse(timeParts[0]);
      final minute = int.parse(timeParts[1]);
      final scheduledDate = DateTime(year, month, day, hour, minute);
      if (scheduledDate.isBefore(DateTime.now())) return;
      tz.initializeTimeZones();
      final tz.TZDateTime tzScheduledDate = tz.TZDateTime.from(scheduledDate, tz.local);
      await flutterLocalNotificationsPlugin.zonedSchedule(
        task.id.hashCode,
        'Task Reminder',
        'You have a pending task: ${task.title}',
        tzScheduledDate,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'task_channel',
            'Task Reminders',
            channelDescription: 'Reminders for your scheduled tasks',
            importance: Importance.max,
            priority: Priority.high,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        matchDateTimeComponents: DateTimeComponents.dateAndTime,
        payload: task.id,
      );
    } catch (e) {
      // Handle error
    }
  }

  Future<void> updateTaskStatus(String taskId, String newStatus) async {
    await FirebaseFirestore.instance.collection('tasks').doc(taskId).update({'status': newStatus});
    final index = _tasks.indexWhere((t) => t.id == taskId);
    if (index != -1) {
      final task = _tasks[index];
      _tasks[index] = TaskModel(
        id: task.id,
        title: task.title,
        description: task.description,
        date: task.date,
        time: task.time,
        label: task.label,
        userId: task.userId,
        status: newStatus,
        location: task.location,
      );
      notifyListeners();
    }
  }

  void clear() {
    _tasks = [];
    _isLoaded = false;
    notifyListeners();
  }
}
