import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../view_models/provider/change_notifier.dart';
import '../../models/task_model.dart';
import 'package:intl/intl.dart';

class CalendarDataScreen extends StatefulWidget {
  const CalendarDataScreen({super.key});

  @override
  State<CalendarDataScreen> createState() => _CalendarDataScreenState();
}

class _CalendarDataScreenState extends State<CalendarDataScreen> {
  late DateTime selectedDate;
  late DateTime windowStartDate;
  String selectedStatus = "All";

  @override
  void initState() {
    super.initState();
    selectedDate = DateTime.now();
    windowStartDate = selectedDate.subtract(const Duration(days: 2));
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    Provider.of<TaskProvider>(context, listen: false).fetchTasks();
  }

  void _moveWindow(int days) {
    setState(() {
      windowStartDate = windowStartDate.add(Duration(days: days));
      // If selectedDate is out of new window, move selection to the middle
      List<DateTime> windowDates = List.generate(5, (i) => windowStartDate.add(Duration(days: i)));
      if (!windowDates.any((d) => _isSameDay(d, selectedDate))) {
        selectedDate = windowDates[2];
      }
    });
  }

  bool _isSameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        scrolledUnderElevation: 0,
        title: const Text(
          "Today's Tasks",
          style: TextStyle(color: Colors.black),
        ),
        automaticallyImplyLeading: false,
        centerTitle: true,
      ),
      body: Consumer<TaskProvider>(
        builder: (context, taskProvider, child) {
          List<TaskModel> tasksForSelectedDate = taskProvider.tasks.where((task) => task.date == DateFormat('yyyy-MM-dd').format(selectedDate)).toList();
          if (selectedStatus != "All") {
            tasksForSelectedDate = tasksForSelectedDate.where((task) => task.status.toLowerCase() == selectedStatus.toLowerCase()).toList();
          }
          List<DateTime> windowDates = List.generate(5, (i) => windowStartDate.add(Duration(days: i)));
          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      GestureDetector(
                        onTap: () => _moveWindow(-5),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 2.0),
                          child: Icon(Icons.chevron_left, size: 32),
                        ),
                      ),
                      ...windowDates.map((date) {
                        bool isSelected = _isSameDay(date, selectedDate);
                        return Expanded(
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                selectedDate = date;
                              });
                            },
                            child: _buildDateBox(date, isSelected),
                          ),
                        );
                      }),
                      GestureDetector(
                        onTap: () => _moveWindow(5),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 2.0),
                          child: Icon(Icons.chevron_right, size: 32),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    children: [
                      _buildCategoryBox("All", isSelected: selectedStatus == "All", onTap: () {
                        setState(() { selectedStatus = "All"; });
                      }),
                      _buildCategoryBox("To Do", isSelected: selectedStatus == "To Do", onTap: () {
                        setState(() { selectedStatus = "To Do"; });
                      }),
                      _buildCategoryBox("Completed", isSelected: selectedStatus == "Completed", onTap: () {
                        setState(() { selectedStatus = "Completed"; });
                      }),
                      _buildCategoryBox("Overdue", isSelected: selectedStatus == "Overdue", onTap: () {
                        setState(() { selectedStatus = "Overdue"; });
                      }),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: tasksForSelectedDate.isEmpty
                      ? Center(
                          child: Text(
                            'No task is added for this date',
                            style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                          ),
                        )
                      : Column(
                          children: tasksForSelectedDate.map((task) {
                            Color cardColor;
                            switch (task.status.toLowerCase()) {
                              case 'completed':
                                cardColor = const Color(0xFFEFFFF7);
                                break;
                              case 'overdue':
                                cardColor = const Color(0xFFFFF6D9);
                                break;
                              case 'to do':
                              default:
                                cardColor = const Color(0xFFF3F8FF);
                                break;
                            }
                            return _buildTaskCard(
                              task.title,
                              task.time,
                              task.status,
                              cardColor,
                            );
                          }).toList(),
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildDateBox(DateTime date, bool isSelected) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
      decoration: BoxDecoration(
        color: isSelected ? const Color(0xFFFFEBEE) : Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: isSelected ? Border.all(color: Colors.pink) : null,
      ),
      child: Column(
        children: [
          Text(
            DateFormat('MMM').format(date),
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            date.day.toString(),
            style: TextStyle(
              color: isSelected ? Colors.black : Colors.grey[600],
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryBox(String label, {bool isSelected = false, VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8),
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        decoration: BoxDecoration(
          color: isSelected ? Colors.pink[100] : const Color(0xFFF7E0E0),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.pink : Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildTaskCard(
      String title, String time, String status, Color backgroundColor) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Task Info
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Icon(Icons.access_time, size: 16, color: Colors.grey[600]),
                  const SizedBox(width: 4),
                  Text(
                    time,
                    style: TextStyle(
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ],
          ),
          // Status Chip
          Container(
            padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              status,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
