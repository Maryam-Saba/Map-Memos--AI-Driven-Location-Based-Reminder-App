import 'package:flutter/material.dart';
import 'aqi_service.dart';
import 'package:provider/provider.dart';
import '../../view_models/provider/change_notifier.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String aqi = "";
  String? _profileImageBase64;

  @override
  void initState() {
    super.initState();
    fetchAQI();
    _loadProfileImage();
  }

  Future<void> fetchAQI() async {
    try {
      final aqiData =
          await AQIService().fetchAQI();
      setState(() {
        aqi = aqiData;
      });
    } catch (e) {
      setState(() {
        aqi = "Error";
      });
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _profileImageBase64 = prefs.getString('profile_image');
    });
  }

  @override
  Widget build(BuildContext context) {
    final userProvider = Provider.of<UserProvider>(context);
    final user = userProvider.user;
    final aqiProvider = Provider.of<AQIProvider>(context);
    final trafficProvider = Provider.of<TrafficProvider>(context);
    final weatherProvider = Provider.of<WeatherProvider>(context);
    final taskProvider = Provider.of<TaskProvider>(context);
    final today = DateTime.now();
    final todayString = "${today.year.toString().padLeft(4, '0')}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}";
    final todaysTasks = taskProvider.tasks.where((task) => task.date == todayString).toList();
    // Calculate completed and total tasks for today
    final int totalTasks = todaysTasks.length;
    final int completedTasks = todaysTasks.where((task) =>
      task.status.toLowerCase() == 'completed'
    ).length;
    final double progress = totalTasks == 0 ? 0 : completedTasks / totalTasks;
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 32,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Hello,",
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    Text(
                      user != null ? "${user.firstName} ${user.lastName}" : "",
                      style: const TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.pink.shade50,
                  backgroundImage: _profileImageBase64 != null
                      ? MemoryImage(base64Decode(_profileImageBase64!))
                      : null,
                  child: _profileImageBase64 == null
                      ? const Icon(Icons.person, size: 30, color: Colors.grey)
                      : null,
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Plan Section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFFFE9DE),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Your plan for today",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "$completedTasks of $totalTasks completed",
                        style: const TextStyle(
                          fontSize: 14,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    width: 100,
                    height: 100,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        SizedBox(
                          width: 80,
                          height: 80,
                          child: CircularProgressIndicator(
                            value: progress,
                            strokeWidth: 15,
                            backgroundColor: Colors.grey[300],
                            color: Colors.orange,
                          ),
                        ),
                        Text(
                          "${(progress * 100).round()}%",
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            const Text(
              "Daily Review",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 10),

            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircleAvatar(
                        radius: 36,
                        backgroundColor: Colors.green,
                        child: Center(
                          child: Text(
                            aqiProvider.aqi ?? "N/A",
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      const SizedBox(
                        width: 80,
                        child: Text(
                          'Air Quality',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 12, color: Colors.black),
                        ),
                      ),
                    ],
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircleAvatar(
                        radius: 36,
                        backgroundColor: Colors.blueGrey,
                        child: Center(
                          child: Text(
                            trafficProvider.trafficUpdate ?? "N/A",
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      const SizedBox(
                        width: 80,
                        child: Text(
                          'Traffic Update',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 12, color: Colors.black),
                        ),
                      ),
                    ],
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircleAvatar(
                        radius: 36,
                        backgroundColor: const Color.fromARGB(255, 231, 176, 217),
                        child: weatherProvider.weather != null
                            ? Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Image.network(
                                    "https://openweathermap.org/img/wn/${weatherProvider.weather!['weather'][0]['icon']}@2x.png",
                                    width: 30,
                                    height: 30,
                                  ),
                                  Text(
                                    "${weatherProvider.weather!['main']['temp']}°C",
                                    style: const TextStyle(
                                        fontSize: 12, color: Colors.white),
                                  ),
                                ],
                              )
                            : const Center(
                                child: Text(
                                  "N/A",
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                      ),
                      const SizedBox(height: 4),
                      const SizedBox(
                        child: Text(
                          'Weather Update',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 12, color: Colors.black),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),
            const Text(
              "Today's tasks",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 2),
            Expanded(
              child: todaysTasks.isEmpty
                  ? const Center(
                      child: Text(
                        'No task added for today',
                        style: TextStyle(fontSize: 16),
                      ),
                    )
                  : ListView.builder(
                    padding: EdgeInsets.zero,
                      itemCount: todaysTasks.length,
                      itemBuilder: (context, index) {
                        final task = todaysTasks[index];
                        final cardColors = [
                          const Color(0xFFFFF6EB), // light peach
                          const Color(0xFFFFF6D9), // light yellow
                          const Color(0xFFEFFFF7), // light green
                          const Color(0xFFF3F8FF), // light blue
                        ];
                        // Deterministic color assignment based on task ID
                        int colorIndex = task.id.hashCode.abs() % cardColors.length;
                        if (index > 0) {
                          int prevColorIndex = todaysTasks[index - 1].id.hashCode.abs() % cardColors.length;
                          if (colorIndex == prevColorIndex) {
                            colorIndex = (colorIndex + 1) % cardColors.length;
                          }
                        }
                        // Determine status to display
                        String displayStatus = task.status;
                        final now = DateTime.now();
                        final todayString = "${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}";
                        if (task.status != 'Completed') {
                          if (task.date == todayString) {
                            displayStatus = 'In Progress';
                          } else {
                            final taskDate = DateTime.tryParse(task.date);
                            if (taskDate != null && taskDate.isBefore(DateTime(now.year, now.month, now.day))) {
                              displayStatus = 'Overdue';
                            }
                          }
                        }
                        return Card(
                          color: cardColors[colorIndex],
                          elevation: 0,
                          child: ListTile(
                            title: Text(
                              task.title,
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            subtitle: Text(
                              task.description,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: Container(
                              padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                displayStatus,
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: displayStatus == 'Completed'
                                      ? Colors.green
                                      : displayStatus == 'Overdue'
                                          ? Colors.red
                                          : Colors.orange,
                                ),
                              ),
                            ),
                            onTap: task.status == 'To Do'
                                ? () async {
                                    final confirmed = await showDialog<bool>(
                                      context: context,
                                      builder: (context) => AlertDialog(
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                                        backgroundColor: Colors.pink.shade50,
                                        title: const Text('Mark as Completed', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black)),
                                        content: Text('Do you want to mark "${task.title}" as completed?', style: const TextStyle(color: Colors.black87)),
                                        actions: [
                                          TextButton(
                                            onPressed: () => Navigator.of(context).pop(false),
                                            child: const Text('Cancel', style: TextStyle(color: Colors.black)),
                                          ),
                                          ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: Colors.green.shade200,
                                              foregroundColor: Colors.white,
                                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                            ),
                                            onPressed: () => Navigator.of(context).pop(true),
                                            child: const Text('Mark Completed'),
                                          ),
                                        ],
                                      ),
                                    );
                                    if (confirmed == true) {
                                      await Provider.of<TaskProvider>(context, listen: false)
                                          .updateTaskStatus(task.id, 'Completed');
                                    }
                                  }
                                : null,
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class TaskCard extends StatelessWidget {
  final String taskName;
  final String time;
  final String status;
  final Color statusColor;

  const TaskCard({super.key, 
    required this.taskName,
    required this.time,
    required this.status,
    required this.statusColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 6,
            spreadRadius: 2,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                taskName,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                time,
                style: const TextStyle(
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
          Text(
            status,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: statusColor,
            ),
          ),
        ],
      ),
    );
  }
}
