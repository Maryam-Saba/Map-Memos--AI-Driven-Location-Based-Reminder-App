import 'dart:convert';
import 'package:http/http.dart' as http;

class AQIService {
  static const String _apiKey = "b9b0ddc8b39d89e6270f664d13c0c4ec";
  static const double _lat = 30.1864; // Correct format for latitude
  static const double _lon = 71.4886; // Correct format for longitude

  // Function to fetch AQI data
  Future<String> fetchAQI() async {
    final url = Uri.parse(
        "http://api.openweathermap.org/data/2.5/air_pollution?lat=$_lat&lon=$_lon&appid=$_apiKey");

    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return data['list'][0]['main']['aqi'].toString(); // Extract AQI value
    } else {
      throw Exception("Failed to load AQI data");
    }
  }
}
