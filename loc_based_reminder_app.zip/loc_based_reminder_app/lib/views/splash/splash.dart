import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../navigation_menu.dart';
import 'package:loc_based_reminder_app/views/log-sign/login.dart';
import 'package:provider/provider.dart';
import '../../view_models/provider/change_notifier.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreen createState() => _SplashScreen();
}

class _SplashScreen extends State<SplashScreen> {

  @override
  void initState() {
    super.initState();
    _handleStartup();
  }

  Future<void> _handleStartup() async {
    await Future.delayed(const Duration(seconds: 2));
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      await Provider.of<UserProvider>(context, listen: false).fetchUser();
      await Provider.of<UserProvider>(context, listen: false).loadProfileImage();
      await Provider.of<UserProvider>(context, listen: false).updateCurrentLocation();
      await Provider.of<AQIProvider>(context, listen: false).fetchAQI();
      await Provider.of<TrafficProvider>(context, listen: false).fetchTraffic();
      await Provider.of<WeatherProvider>(context, listen: false).fetchWeather();
      await Provider.of<TaskProvider>(context, listen: false).fetchTasks();
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const NavigationMenu()),
      );
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginPage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 247, 239, 224),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'assets/images/LOGO 1.png',
              width: 150,
              height: 150,
            ),
            const SizedBox(height: 10),
            const Text(
              'Map Memos',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
                fontSize: 49,
                color: Color(0xFF907F46),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
