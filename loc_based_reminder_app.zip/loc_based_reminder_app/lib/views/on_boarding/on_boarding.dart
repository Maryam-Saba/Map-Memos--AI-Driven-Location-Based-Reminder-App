import 'package:flutter/material.dart';
import 'package:loc_based_reminder_app/views/log-sign/login.dart';

class OnboardingScreen extends StatefulWidget {
  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _controller = PageController();
  int _currentPage = 0;

  final List<Map<String, dynamic>> _onboardingData = [
    {
      "image": "assets/images/onboarding_1.png",
      "title": "Welcome to Map Memos",
      "description":
          "Allow Map Memos to access this device's location all the time?",
      "backgroundColor": Color(0xFFFFFFFF),
      "layoutType": "old", // Old layout
    },
    {
      "image": "assets/images/onboarding_2.png",
      "title": "Map Memos would like to send you notifications",
      "description":
          "Notifications may include alerts, reminders, and sounds. You can configure this in Settings.",
      "backgroundColor": Color(0xFFE8F4F8),
      "layoutType": "new", // New layout
    },
    {
      "image": "assets/images/onboarding_3.png",
      "title": "Let Map Memos always run in the background?",
      "description":
          "Allowing Map Memos to always run in the background may reduce battery life. You can change this later from Settings.",
      "backgroundColor": Color(0xFFF7E0E0),
      "layoutType": "old", // Old layout
    },
    {
      "image": "assets/images/onboarding_4.png",
      "title": "Map Memos would like to access your Calendar",
      "description": "Calendars are used to show tasks and events.",
      "backgroundColor": Color(0xFFF9F3D7),
      "layoutType": "new", // New layout
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // PageView
          PageView.builder(
            controller: _controller,
            itemCount: _onboardingData.length,
            onPageChanged: (index) {
              setState(() {
                _currentPage = index;
              });
            },
            itemBuilder: (context, index) {
              return _buildPage(
                image: _onboardingData[index]["image"]!,
                title: _onboardingData[index]["title"]!,
                description: _onboardingData[index]["description"]!,
                backgroundColor: _onboardingData[index]["backgroundColor"]!,
                layoutType: _onboardingData[index]["layoutType"]!,
              );
            },
          ),

          // Floating Button
          Positioned(
            bottom: 40, // Adjust to control the height of the floating button
            left: 16,
            right: 16,
            child: ElevatedButton(
              onPressed: () {
                if (_currentPage < _onboardingData.length - 1) {
                  _controller.nextPage(
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.ease,
                  );
                } else {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => LoginPage(),
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                elevation: 5,
                minimumSize: const Size(double.infinity, 50),
              ),
              child: Text(
                _currentPage < _onboardingData.length - 1
                    ? "Next"
                    : "Get Started",
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Poppins',
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPage({
    required String image,
    required String title,
    required String description,
    required Color backgroundColor,
    required String layoutType,
  }) {
    if (layoutType == "old") {
      return Container(
        color: backgroundColor,
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(image, width: 200, height: 200),
            const SizedBox(height: 32),
            Text(
              title,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                fontFamily: 'Poppins',
                color: Color(0xFF000000),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                description,
                style: const TextStyle(
                  fontSize: 16,
                  fontFamily: 'Poppins',
                  color: Color(0xFF7D7D7D),
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      );
    } else {
      return Container(
        color: backgroundColor,
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                fontFamily: 'Poppins',
                color: Color(0xFF000000),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                description,
                style: const TextStyle(
                  fontSize: 16,
                  fontFamily: 'Poppins',
                  color: Color(0xFF7D7D7D),
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 32),
            Image.asset(image, width: 200, height: 200),
          ],
        ),
      );
    }
  }
}
