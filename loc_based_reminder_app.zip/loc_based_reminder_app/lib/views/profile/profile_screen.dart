import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'dart:convert';
import '../../view_models/provider/change_notifier.dart';
import '../log-sign/login.dart';
import 'edit_profile_screen.dart';
import 'privacy_policy_screen.dart';
import 'monthly_progress_screen.dart';
import 'profile_tile.dart';
import 'pink_background_clipper.dart';

class ProfileScreen0 extends StatefulWidget {
  const ProfileScreen0({super.key});

  @override
  State<ProfileScreen0> createState() => _ProfileScreen0State();
}

class _ProfileScreen0State extends State<ProfileScreen0> {
  String? _profileImageBase64;

  @override
  void initState() {
    super.initState();
    _loadProfileImage();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _profileImageBase64 = prefs.getString('profile_image');
    });
  }


  Future<bool> _getNotificationStatus() async {
    return await AwesomeNotifications().isNotificationAllowed();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                ClipPath(
                  clipper: PinkBackgroundClipper(),
                  child: Container(
                    height: size.height * 0.28,
                    width: double.infinity,
                    color: Colors.pink.shade50,
                  ),
                ),
                Positioned(
                  top: size.height * 0.19,
                  left: 0,
                  right: 0,
                  child: Consumer<UserProvider>(
                    builder: (context, userProvider, _) {
                      final user = userProvider.user;
                      final String name = user != null ? "${user.firstName} ${user.lastName}" : "Name";
                      final String email = user?.email ?? "email@domain.com";
                      return Column(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.pink.withOpacity(0.15),
                                  blurRadius: 16,
                                  offset: const Offset(0, 8),
                                ),
                              ],
                              border: Border.all(color: Colors.white, width: 4),
                            ),
                            child: CircleAvatar(
                              radius: 44,
                              backgroundColor: Colors.pink.shade50,
                              backgroundImage: _profileImageBase64 != null
                                  ? MemoryImage(base64Decode(_profileImageBase64!))
                                  : null,
                              child: _profileImageBase64 == null
                                  ? const Icon(Icons.person, size: 44, color: Colors.grey)
                                  : null,
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            name,
                            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            email,
                            style: TextStyle(color: Colors.grey[600], fontSize: 14),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: size.height * 0.12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18.0, vertical: 8.0),
              child: Column(
                children: [
                  profileListTile(
                    context,
                    icon: Icons.edit_document,
                    title: 'Edit Profile Information',
                    trailing: Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey[500]),
                    onTap: () async {
                      await Navigator.push(context, MaterialPageRoute(builder: (_) => EditProfileScreen()));
                      _loadProfileImage(); // reload after returning
                    },
                  ),
                  Divider(height: 1, thickness: 0.5, color: Colors.grey[300]),
                  FutureBuilder<bool>(
                    future: _getNotificationStatus(),
                    builder: (context, snapshot) {
                      final bool isOn = snapshot.data ?? false;
                      return profileListTile(
                        context,
                        icon: Icons.notifications,
                        title: 'Notifications',
                        trailing: Text(
                          isOn ? 'ON' : 'OFF',
                          style: TextStyle(
                            color: isOn ? Colors.blue : Colors.red,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        onTap: () {},
                      );
                    },
                  ),
                  Divider(height: 1, thickness: 0.5, color: Colors.grey[300]),
                  profileListTile(
                    context,
                    icon: Icons.pie_chart_rounded,
                    title: 'Your Progress',
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const MonthlyProgressScreen()));
                    },
                  ),
                  Divider(height: 1, thickness: 0.5, color: Colors.grey[300]),
                  profileListTile(
                    context,
                    icon: Icons.privacy_tip_outlined,
                    title: 'Privacy Policy',
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen()));
                    },
                  ),
                  Divider(height: 1, thickness: 0.5, color: Colors.grey[300]),
                  profileListTile(
                    context,
                    icon: Icons.logout,
                    iconColor: Colors.red,
                    title: 'Logout',
                    titleColor: Colors.red,
                    onTap: () async {
                      final user = FirebaseAuth.instance.currentUser;
                      final token = await FirebaseMessaging.instance.getToken();
                      if (user != null && token != null) {
                        await FirebaseFirestore.instance.collection('users').doc(user.uid).update({
                          'tokens': FieldValue.arrayRemove([token])
                        });
                      }
                      await FirebaseAuth.instance.signOut();
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => LoginPage()),
                        (route) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
} 