import 'package:flutter/material.dart';
import 'package:awesome_notifications/awesome_notifications.dart';

class ProfileScreen2 extends StatefulWidget {
  @override
  _ProfileScreen2State createState() => _ProfileScreen2State();
}

class _ProfileScreen2State extends State<ProfileScreen2> {
  bool general = true;
  bool sound = false;
  bool vibrate = false;
  bool notificationAllowed = false;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _fetchNotificationStatus();
  }

  Future<void> _fetchNotificationStatus() async {
    final allowed = await AwesomeNotifications().isNotificationAllowed();
    setState(() {
      notificationAllowed = allowed;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        foregroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(24),
              children: [
                const Text('Common', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.black)),
                const SizedBox(height: 12),
                SwitchListTile(
                  title: const Text('General Notification', style: TextStyle(fontWeight: FontWeight.w500)),
                  value: notificationAllowed,
                  onChanged: (val) async {
                    if (!val) {
                      // Open app settings if user tries to turn off
                      await AwesomeNotifications().requestPermissionToSendNotifications();
                    } else {
                      await AwesomeNotifications().requestPermissionToSendNotifications();
                    }
                    await _fetchNotificationStatus();
                  },
                  activeColor: Colors.pink,
                  inactiveThumbColor: Colors.grey,
                  inactiveTrackColor: Colors.grey[300],
                ),
                SwitchListTile(
                  title: const Text('Sound', style: TextStyle(fontWeight: FontWeight.w500)),
                  value: sound,
                  onChanged: notificationAllowed
                      ? (val) => setState(() => sound = val)
                      : null,
                  activeColor: Colors.pink,
                  inactiveThumbColor: Colors.grey,
                  inactiveTrackColor: Colors.grey[300],
                ),
                SwitchListTile(
                  title: const Text('Vibrate', style: TextStyle(fontWeight: FontWeight.w500)),
                  value: vibrate,
                  onChanged: notificationAllowed
                      ? (val) => setState(() => vibrate = val)
                      : null,
                  activeColor: Colors.pink,
                  inactiveThumbColor: Colors.grey,
                  inactiveTrackColor: Colors.grey[300],
                ),
                const SizedBox(height: 20),
                if (!notificationAllowed)
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.pink.shade100,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Text(
                      'Notifications are disabled in system settings. Enable them to use sound and vibration.',
                      style: TextStyle(color: Colors.black, fontWeight: FontWeight.w500),
                    ),
                  ),
              ],
            ),
    );
  }
} 