import 'package:flutter/material.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Privacy Policy', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        centerTitle: true,
        scrolledUnderElevation: 0,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        color: Colors.pink.shade50,
        child: const SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Location-Based Reminder App Privacy Policy',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black, fontFamily: 'Poppins'),
              ),
              SizedBox(height: 18),
              Text(
                'Effective Date: July 2024',
                style: TextStyle(fontSize: 15, color: Colors.black87, fontWeight: FontWeight.w600),
              ),
              SizedBox(height: 18),
              Text(
                '1. Information We Collect',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
              ),
              SizedBox(height: 6),
              Text(
                '• Location Data: We collect your device’s location to provide location-based reminders and suggestions.\n'
                '• Account Information: We collect your name, email, and profile image for account management.\n'
                '• Task Data: We store your reminders, tasks, and related notes securely in the cloud.\n'
                '• Device Information: We may collect device and usage data to improve app performance.',
                style: TextStyle(fontSize: 15, color: Colors.black87),
              ),
              SizedBox(height: 18),
              Text(
                '2. How We Use Your Information',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
              ),
              SizedBox(height: 6),
              Text(
                '• To deliver reminders and notifications based on your location and preferences.\n'
                '• To personalize your experience and provide AI-based planning suggestions.\n'
                '• To improve app features, security, and reliability.\n'
                '• We do not sell or share your personal data with third parties for marketing.',
                style: TextStyle(fontSize: 15, color: Colors.black87),
              ),
              SizedBox(height: 18),
              Text(
                '3. Data Security',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
              ),
              SizedBox(height: 6),
              Text(
                '• Your data is encrypted in transit and stored securely in the cloud.\n'
                '• Only you can access your reminders and personal information.',
                style: TextStyle(fontSize: 15, color: Colors.black87),
              ),
              SizedBox(height: 18),
              Text(
                '4. Permissions',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
              ),
              SizedBox(height: 6),
              Text(
                '• The app requests location, notification, and storage permissions only as needed for core features.',
                style: TextStyle(fontSize: 15, color: Colors.black87),
              ),
              SizedBox(height: 18),
              Text(
                '5. Your Choices',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
              ),
              SizedBox(height: 6),
              Text(
                '• You can update or delete your account and tasks at any time.\n'
                '• You can control app permissions in your device settings.',
                style: TextStyle(fontSize: 15, color: Colors.black87),
              ),
              SizedBox(height: 18),
              Text(
                '6. Contact Us',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
              ),
              SizedBox(height: 6),
              Text(
                'If you have questions or concerns about your privacy, please contact us at support@locreminderapp.com.',
                style: TextStyle(fontSize: 15, color: Colors.black87),
              ),
              SizedBox(height: 24),
              Center(
                child: Text(
                  'Thank you for trusting us with your reminders!',
                  style: TextStyle(fontSize: 15, color: Colors.pink, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
} 