import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../views/log-sign/login.dart';

Widget profileListTile(BuildContext context, {required IconData icon, Color? iconColor, required String title, Color? titleColor, Widget? trailing, VoidCallback? onTap}) {
  final bool isLogout = title.toLowerCase() == 'logout';
  return ListTile(
    contentPadding: const EdgeInsets.symmetric(vertical: 2, horizontal: 0),
    leading: Container(
      decoration: BoxDecoration(
        color: Colors.pink.shade50,
        borderRadius: BorderRadius.circular(10),
      ),
      padding: const EdgeInsets.all(8),
      child: Icon(icon, color: iconColor ?? Colors.pink, size: 24),
    ),
    title: Text(
      title,
      style: TextStyle(
        color: titleColor ?? Colors.black,
        fontWeight: FontWeight.w500,
        fontSize: 16,
      ),
    ),
    trailing: trailing,
    onTap: isLogout
        ? () async {
            final confirmed = await showDialog<bool>(
              context: context,
              builder: (context) => AlertDialog(
                title: const Text('Logout'),
                content: const Text('Are you sure you want to logout?'),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: const Text('Cancel',style: TextStyle(color: Colors.black),),
                  ),
                  ElevatedButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                    ),
                    child: const Text('Logout'),
                  ),
                ],
              ),
            );
            if (confirmed == true) {
              final user = FirebaseAuth.instance.currentUser;
              final token = await FirebaseMessaging.instance.getToken();
              if (user != null && token != null) {
                await FirebaseFirestore.instance.collection('users').doc(user.uid).update({
                  'tokens': FieldValue.arrayRemove([token])
                });
              }
              await FirebaseAuth.instance.signOut();
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => LoginPage()),
                (route) => false,
              );
            }
          }
        : onTap,
    horizontalTitleGap: 12,
    minVerticalPadding: 12,
    splashColor: Colors.transparent,
    hoverColor: Colors.transparent,
    focusColor: Colors.transparent,
    enableFeedback: false,
  );
} 