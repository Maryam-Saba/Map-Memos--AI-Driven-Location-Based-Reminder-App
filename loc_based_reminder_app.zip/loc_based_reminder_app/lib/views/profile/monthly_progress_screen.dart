import 'package:flutter/material.dart';
import 'dart:math';
import 'package:provider/provider.dart';
import '../../view_models/provider/change_notifier.dart';

class MonthlyProgressScreen extends StatefulWidget {
  const MonthlyProgressScreen({super.key});

  @override
  State<MonthlyProgressScreen> createState() => _MonthlyProgressScreenState();
}

class _MonthlyProgressScreenState extends State<MonthlyProgressScreen> {
  DateTime _selectedMonth = DateTime(DateTime.now().year, DateTime.now().month);

  List<DateTime> _getMonthOptions(List tasks) {
    final now = DateTime.now();
    List<DateTime> months = [];
    for (int i = 0; i < 12; i++) {
      final month = DateTime(now.year, now.month - i);
      months.add(month);
    }
    months = months.reversed.toList();
    return months;
  }

  String _monthName(int month) {
    const months = [
      '',
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    return months[month];
  }

  List<DateTime> _getCurrentWeekDays() {
    final now = DateTime.now();
    final monday = now.subtract(Duration(days: now.weekday - 1));
    return List.generate(7, (i) => monday.add(Duration(days: i)));
  }

  List<DateTime> _getPreviousWeekDays() {
    final now = DateTime.now();
    final lastMonday = now.subtract(Duration(days: now.weekday + 6));
    return List.generate(7, (i) => lastMonday.add(Duration(days: i)));
  }

  String _weekRangeString(List<DateTime> week) {
    final start = week.first;
    final end = week.last;
    final monthShort = _monthName(start.month).substring(0, 3);
    return '$monthShort ${start.day}-${end.day}';
  }

  String _formatDate(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Progress',
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        centerTitle: true,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: Consumer<TaskProvider>(
        builder: (context, taskProvider, child) {
          final allTasks = taskProvider.tasks;
          // Monthly Progress Data
          final tasks = allTasks.where((t) {
            final date = DateTime.tryParse(t.date);
            return date != null &&
                date.year == _selectedMonth.year &&
                date.month == _selectedMonth.month;
          }).toList();
          final int totalTasks = tasks.length;
          final int completedTasks =
              tasks.where((t) => t.status.toLowerCase() == 'completed').length;
          final int remainingTasks = totalTasks - completedTasks;
          final monthOptions = _getMonthOptions(allTasks);

          // Daily Goals Data (current week)
          final weekDays = _getCurrentWeekDays();
          final dailyGoals = weekDays.map((day) {
            final dateStr = _formatDate(day);
            final dayTasks = allTasks.where((t) => t.date == dateStr).toList();
            final int total = dayTasks.length;
            final int completed = dayTasks.where((t) => t.status.toLowerCase() == 'completed').length;
            return {
              'date': day,
              'total': total,
              'completed': completed,
            };
          }).toList();
          final achievedDays = dailyGoals
              .where((g) => ((g['total'] ?? 0) as int) > 0 && ((g['completed'] ?? 0) as int) == ((g['total'] ?? 0) as int))
              .length;

          // Previous week summary
          final prevWeek = _getPreviousWeekDays();
          final prevWeekGoals = prevWeek.map((day) {
            final dayTasks = allTasks
                .where((t) =>
                    t.date ==
                    '${day.year.toString().padLeft(4, '0')}-${day.month.toString().padLeft(2, '0')}-${day.day.toString().padLeft(2, '0')}')
                .toList();
            final total = dayTasks.length;
            final completed = dayTasks
                .where((t) => t.status.toLowerCase() == 'completed')
                .length;
            return {
              'date': day,
              'total': total,
              'completed': completed,
            };
          }).toList();
          final int safePrevTotal = prevWeekGoals.fold<int>(
              0,
              (sum, g) =>
                  sum + (int.tryParse(g['total']?.toString() ?? '0') ?? 0));
          final int safePrevCompleted = prevWeekGoals.fold<int>(
              0,
              (sum, g) =>
                  sum + (int.tryParse(g['completed']?.toString() ?? '0') ?? 0));
          String weeklyMsg;
          Color weeklyColor;
          if (safePrevTotal == 0) {
            weeklyMsg = "No tasks last week.";
            weeklyColor = Colors.grey.shade100;
          } else if (safePrevCompleted == safePrevTotal) {
            weeklyMsg = "You hit your weekly target!";
            weeklyColor = Colors.yellow.shade100;
          } else if (safePrevCompleted == 0) {
            weeklyMsg = "You missed all your tasks last week.";
            weeklyColor = Colors.red.shade50;
          } else {
            weeklyMsg =
                "You completed $safePrevCompleted out of $safePrevTotal tasks last week.";
            weeklyColor = Colors.orange.shade50;
          }
          final weekRange = _weekRangeString(prevWeek);

          return SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Monthly Progress Graph
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.pink.withOpacity(0.08),
                          blurRadius: 16,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 18, horizontal: 12),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'Monthly Progress',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Poppins',
                                  color: Colors.black,
                                ),
                              ),
                              GestureDetector(
                                onTap: () async {
                                  final selected =
                                      await showModalBottomSheet<DateTime>(
                                    context: context,
                                    shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.vertical(
                                          top: Radius.circular(20)),
                                    ),
                                    builder: (context) {
                                      return SizedBox(
                                        height: 350,
                                        child: Column(
                                          children: [
                                            const SizedBox(height: 16),
                                            const Text('Select Month',
                                                style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 18)),
                                            const Divider(),
                                            Expanded(
                                              child: ListView.builder(
                                                itemCount: monthOptions.length,
                                                itemBuilder: (context, idx) {
                                                  final m = monthOptions[idx];
                                                  return ListTile(
                                                    title: Text(
                                                        '${_monthName(m.month)} ${m.year}'),
                                                    selected: m.year ==
                                                            _selectedMonth
                                                                .year &&
                                                        m.month ==
                                                            _selectedMonth
                                                                .month,
                                                    onTap: () => Navigator.pop(
                                                        context, m),
                                                  );
                                                },
                                              ),
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  );
                                  if (selected != null)
                                    setState(() => _selectedMonth = selected);
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: Colors.grey.withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child: Row(
                                    children: [
                                      Text(
                                        '${_monthName(_selectedMonth.month)} ${_selectedMonth.year}',
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w600,
                                          color: Colors.black87,
                                          fontSize: 15,
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      const Icon(
                                          Icons.keyboard_arrow_down_rounded,
                                          size: 20,
                                          color: Colors.black54),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          SizedBox(
                            height: 140,
                            width: 140,
                            child: _DualRingProgress(
                              completed: completedTasks,
                              remaining: remainingTasks,
                              total: totalTasks,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 12,
                                    height: 12,
                                    decoration: const BoxDecoration(
                                      color: Color(0xFFFFA6A6),
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  const Text('Remaining',
                                      style: TextStyle(
                                          fontSize: 14, color: Colors.black)),
                                ],
                              ),
                              const SizedBox(width: 18),
                              Row(
                                children: [
                                  Container(
                                    width: 12,
                                    height: 12,
                                    decoration: const BoxDecoration(
                                      color: Color(0xFF7BCFA6),
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  const Text('Completed',
                                      style: TextStyle(
                                          fontSize: 14, color: Colors.black)),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  // Daily Goals Widget
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8E8FF),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 18, horizontal: 18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Your daily goals',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 17)),
                          const SizedBox(height: 2),
                          const Text('Last 7 days',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.black54)),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              Text('$achievedDays/7',
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFF7BCFA6),
                                      fontSize: 18)),
                              const SizedBox(width: 8),
                              const Text('Achieved',
                                  style: TextStyle(
                                      fontSize: 14,
                                      color: Color(0xFF7BCFA6),
                                      fontWeight: FontWeight.w600)),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: List.generate(7, (i) {
                              final g = dailyGoals[i];
                              final isToday = DateTime.now().day ==
                                      (g['date'] as DateTime).day &&
                                  DateTime.now().month ==
                                      (g['date'] as DateTime).month &&
                                  DateTime.now().year ==
                                      (g['date'] as DateTime).year;
                              final int total = g['total'] as int;
                              final int completed = g['completed'] as int;
                              final achieved = total > 0 && completed == total;
                              final percent = total == 0 ? 0.0 : completed / total;
                              final dayLetter =
                                  ['F', 'S', 'S', 'M', 'T', 'W', 'T'][i];
                              return Column(
                                children: [
                                  Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      SizedBox(
                                        width: 38,
                                        height: 38,
                                        child: CustomPaint(
                                          painter: _DayProgressRingPainter(
                                              percent: percent,
                                              achieved: achieved),
                                        ),
                                      ),
                                      Container(
                                        width: 28,
                                        height: 28,
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                              color: isToday
                                                  ? Colors.pink
                                                  : Colors.transparent,
                                              width: 2),
                                        ),
                                        child: achieved
                                            ? const Icon(Icons.check_circle,
                                                color: Color(0xFF7BCFA6),
                                                size: 20)
                                            : null,
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Text(dayLetter,
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 13)),
                                ],
                              );
                            }),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  // Weekly Target Widget
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: weeklyColor,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 18, horizontal: 18),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              weeklyMsg,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 16),
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(weekRange,
                                  style: const TextStyle(
                                      fontSize: 14, color: Colors.black54)),
                              if (safePrevCompleted == safePrevTotal &&
                                  safePrevTotal > 0)
                                const Icon(Icons.check_circle,
                                    color: Color(0xFF7BCFA6), size: 20),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _DualRingProgress extends StatelessWidget {
  final int completed;
  final int remaining;
  final int total;
  const _DualRingProgress(
      {required this.completed, required this.remaining, required this.total});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: const Size(140, 140),
      painter: _DualRingPainter(
          completed: completed, remaining: remaining, total: total),
    );
  }
}

class _DualRingPainter extends CustomPainter {
  final int completed;
  final int remaining;
  final int total;
  _DualRingPainter(
      {required this.completed, required this.remaining, required this.total});

  @override
  void paint(Canvas canvas, Size size) {
    final outerStroke = 16.0;
    final innerStroke = 10.0;
    final center = Offset(size.width / 2, size.height / 2);
    final outerRadius = (size.width - outerStroke) / 2;
    final innerRadius = (size.width - innerStroke) / 2 - 24;
    final rectOuter = Rect.fromCircle(center: center, radius: outerRadius);
    final rectInner = Rect.fromCircle(center: center, radius: innerRadius);
    final bgOuterPaint = Paint()
      ..color = const Color(0xFFE5E5E5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = outerStroke;
    final bgInnerPaint = Paint()
      ..color = const Color(0xFFE5E5E5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = innerStroke;
    final completedPaint = Paint()
      ..color = const Color(0xFF7BCFA6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = outerStroke
      ..strokeCap = StrokeCap.round;
    final remainingPaint = Paint()
      ..color = const Color(0xFFFFA6A6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = innerStroke
      ..strokeCap = StrokeCap.round;
    // Outer ring (completed)
    canvas.drawArc(rectOuter, -pi / 2, 2 * pi, false, bgOuterPaint);
    if (total > 0 && completed > 0) {
      canvas.drawArc(rectOuter, -pi / 2, 2 * pi * (completed / total), false, completedPaint);
    }
    // Inner ring (remaining)
    canvas.drawArc(rectInner, -pi / 2, 2 * pi, false, bgInnerPaint);
    if (total > 0 && remaining > 0) {
      canvas.drawArc(rectInner, -pi / 2, 2 * pi * (remaining / total), false, remainingPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// Day progress ring for daily goals
class _DayProgressRingPainter extends CustomPainter {
  final double percent;
  final bool achieved;
  _DayProgressRingPainter({required this.percent, required this.achieved});

  @override
  void paint(Canvas canvas, Size size) {
    final stroke = 4.0;
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width - stroke) / 2;
    final rect = Rect.fromCircle(center: center, radius: radius);
    final bgPaint = Paint()
      ..color = const Color(0xFFE5E5E5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke;
    final progressPaint = Paint()
      ..color = achieved
          ? const Color(0xFF7BCFA6)
          : const Color(0xFF7BCFA6).withOpacity(0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(rect, -pi / 2, 2 * pi, false, bgPaint);
    if (percent > 0) {
      canvas.drawArc(rect, -pi / 2, 2 * pi * percent, false, progressPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
