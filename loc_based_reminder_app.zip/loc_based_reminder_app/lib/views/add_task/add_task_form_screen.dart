import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/task_model.dart';
import '../../view_models/provider/change_notifier.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AddTaskFormScreen extends StatefulWidget {
  const AddTaskFormScreen({super.key});

  @override
  State<AddTaskFormScreen> createState() => _AddTaskFormScreenState();
}

class _AddTaskFormScreenState extends State<AddTaskFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _timeController = TextEditingController();
  final TextEditingController _notificationTime24hController = TextEditingController();
  String? _selectedLabel;
  Map<String, double>? _selectedLocation;
  bool _isSaving = false;

  Future<void> _selectDate() async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (pickedDate != null) {
      _dateController.text = pickedDate.toString().split(' ')[0];
    }
  }

  Future<void> _selectTime() async {
    TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (pickedTime != null) {
      _timeController.text = pickedTime.format(context); // old flow
      // New: store 24-hour format for notifications
      final hour = pickedTime.hour.toString().padLeft(2, '0');
      final minute = pickedTime.minute.toString().padLeft(2, '0');
      _notificationTime24hController.text = '$hour:$minute';
    }
  }

  Future<void> _selectLocation() async {
    final picked = await Navigator.push<Map<String, double>>(
      context,
      MaterialPageRoute(builder: (context) => const MapPickerScreen()),
    );
    if (picked != null) {
      setState(() {
        _selectedLocation = picked;
      });
    }
  }

  void _saveTask() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    final task = TaskModel(
      id: '',
      title: _titleController.text.trim(),
      description: _descriptionController.text.trim(),
      date: _dateController.text.trim(),
      time: _timeController.text.trim(),
      label: _selectedLabel!,
      location: _selectedLocation,
      userId: user.uid,
      status: 'To Do',
      notificationTime24h: _notificationTime24hController.text.trim(),
    );
    print('[AddTask] Adding task to Firestore: ' + task.toMap().toString());
    await Provider.of<TaskProvider>(context, listen: false).addTask(task);
    setState(() => _isSaving = false);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Task'),
        centerTitle: true,
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.bold,
          fontSize: 22,
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'Title',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.isEmpty ? 'Title is required' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Description',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.isEmpty ? 'Description is required' : null,
                maxLines: 3,
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _dateController,
                      readOnly: true,
                      decoration: const InputDecoration(
                        labelText: 'Date',
                        border: OutlineInputBorder(),
                        suffixIcon: Icon(Icons.calendar_today),
                      ),
                      validator: (value) => value == null || value.isEmpty ? 'Date is required' : null,
                      onTap: _selectDate,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _timeController,
                      readOnly: true,
                      decoration: const InputDecoration(
                        labelText: 'Time',
                        border: OutlineInputBorder(),
                        suffixIcon: Icon(Icons.access_time),
                      ),
                      validator: (value) => value == null || value.isEmpty ? 'Time is required' : null,
                      onTap: _selectTime,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _selectedLabel,
                decoration: const InputDecoration(
                  labelText: 'Label',
                  border: OutlineInputBorder(),
                ),
                items: ['Work', 'Personal', 'Fitness', 'Shopping']
                    .map((label) => DropdownMenuItem(
                          value: label,
                          child: Text(label),
                        ))
                    .toList(),
                onChanged: (value) => setState(() => _selectedLabel = value),
                validator: (value) => value == null || value.isEmpty ? 'Label is required' : null,
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: _selectLocation,
                      child: AbsorbPointer(
                        child: TextFormField(
                          readOnly: true,
                          decoration: const InputDecoration(
                            labelText: 'Location (optional)',
                            border: OutlineInputBorder(),
                            suffixIcon: Icon(Icons.location_on),
                          ),
                          controller: TextEditingController(
                            text: _selectedLocation == null
                                ? ''
                                : 'Lat: ${_selectedLocation!['lat']?.toStringAsFixed(5)}, Lng: ${_selectedLocation!['lng']?.toStringAsFixed(5)}',
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 32),
              SizedBox(
                height: 50,
                child: ElevatedButton(
                  onPressed: _isSaving ? null : _saveTask,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: _isSaving
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('Save', style: TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MapPickerScreen extends StatefulWidget {
  const MapPickerScreen({super.key});

  @override
  State<MapPickerScreen> createState() => _MapPickerScreenState();
}

class _MapPickerScreenState extends State<MapPickerScreen> {
  LatLng? _pickedLocation;
  // ignore: unused_field
  GoogleMapController? _mapController;
  CameraPosition? _initialCameraPosition;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadInitialCameraPosition();
  }

  Future<void> _loadInitialCameraPosition() async {
    final user = FirebaseAuth.instance.currentUser;
    CameraPosition cameraPosition = const CameraPosition(
      target: LatLng(30.1575, 71.5249),
      zoom: 12,
    );
    if (user != null) {
      final doc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final data = doc.data();
      if (data != null && data['currentLocation'] != null) {
        final loc = data['currentLocation'];
        if (loc['lat'] != null && loc['lng'] != null) {
          cameraPosition = CameraPosition(
            target: LatLng((loc['lat'] as num).toDouble(), (loc['lng'] as num).toDouble()),
            zoom: 15,
          );
        }
      }
    }
    setState(() {
      _initialCameraPosition = cameraPosition;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pick Location'),
        backgroundColor: const Color(0xFFFFE9DE),
        iconTheme: const IconThemeData(color: Color(0xFF907F46)),
        titleTextStyle: const TextStyle(
          color: Color(0xFF907F46),
          fontFamily: 'Poppins',
          fontWeight: FontWeight.bold,
          fontSize: 22,
        ),
        elevation: 0,
      ),
      body: Stack(
        children: [
          _loading || _initialCameraPosition == null
              ? const Center(child: CircularProgressIndicator())
              : GoogleMap(
                  initialCameraPosition: _initialCameraPosition!,
                  onMapCreated: (controller) => _mapController = controller,
                  onTap: (latLng) {
                    setState(() {
                      _pickedLocation = latLng;
                    });
                  },
                  markers: _pickedLocation == null
                      ? {}
                      : {
                          Marker(
                            markerId: const MarkerId('picked'),
                            position: _pickedLocation!,
                          ),
                        },
                ),
          Positioned(
            left: 24,
            right: 24,
            bottom: 32,
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                onPressed: _pickedLocation == null
                    ? null
                    : () {
                        Navigator.pop(context, {
                          'lat': _pickedLocation!.latitude,
                          'lng': _pickedLocation!.longitude,
                        });
                      },
                icon: const Icon(Icons.check, color: Color(0xFF907F46)),
                label: const Text(
                  'Select',
                  style: TextStyle(
                    color: Color(0xFF907F46),
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Poppins',
                    fontSize: 18,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFFE9DE),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 4,
                  disabledBackgroundColor: Colors.grey[300],
                  disabledForegroundColor: Colors.grey[600],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
} 