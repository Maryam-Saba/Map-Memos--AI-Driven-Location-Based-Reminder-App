import 'package:flutter/material.dart';
import 'package:loc_based_reminder_app/views/add_task/add_task_form_screen.dart';
import 'package:provider/provider.dart';
import '../../view_models/provider/change_notifier.dart';

class AddTaskScreen extends StatefulWidget {
  const AddTaskScreen({super.key});

  @override
  _AddTaskScreenState createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  DateTime _selectedMonth = DateTime(DateTime.now().year, DateTime.now().month);

  List<DateTime> _getMonthOptions() {
    final tasks = Provider.of<TaskProvider>(context, listen: false).tasks;
    if (tasks.isEmpty) {
      return [DateTime(DateTime.now().year, DateTime.now().month)];
    }
    final dates = tasks.map((t) => DateTime.tryParse(t.date)).whereType<DateTime>().toList();
    if (dates.isEmpty) {
      return [DateTime(DateTime.now().year, DateTime.now().month)];
    }
    dates.sort();
    final first = DateTime(dates.first.year, dates.first.month);
    final now = DateTime.now();
    final last = DateTime(now.year, now.month);
    List<DateTime> months = [];
    DateTime current = first;
    while (!current.isAfter(last)) {
      months.add(current);
      current = DateTime(current.year, current.month + 1);
    }
    return months;
  }

  Future<void> _navigateToAddTaskForm() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const AddTaskFormScreen()),
    );
    await Provider.of<TaskProvider>(context, listen: false).fetchTasks();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    Provider.of<TaskProvider>(context, listen: false).fetchTasks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Reminders',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            fontSize: 20,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Image.asset('assets/icons/Add Square 03.png'),
            onPressed: _navigateToAddTaskForm,
          ),
        ],
      ),
      body: Consumer<TaskProvider>(
        builder: (context, taskProvider, child) {
          final allTasks = taskProvider.tasks;
          // Filter tasks for selected month
          final tasks = allTasks.where((t) {
            final date = DateTime.tryParse(t.date);
            return date != null && date.year == _selectedMonth.year && date.month == _selectedMonth.month;
          }).toList();
          final int totalTasks = tasks.length;
          final int completedTasks = tasks.where((t) => t.status.toLowerCase() == 'completed').length;
          final double completedPercent = totalTasks == 0 ? 0 : completedTasks / totalTasks;
          final double remainingPercent = 1 - completedPercent;
          final monthOptions = _getMonthOptions();
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Removed Monthly Progress Section
              const SizedBox(height: 8),
              // Tasks Section
              tasks.isEmpty
                  ? const Expanded(
                      child: Center(
                        child: Text(
                          'No tasks yet! Tap the + button to add a task.',
                          style: TextStyle(fontSize: 16),
                        ),
                      ),
                    )
                  : Expanded(
                      child: ListView.builder(
                        itemCount: tasks.length,
                        itemBuilder: (context, index) {
                          final task = tasks[index];
                          final cardColors = [
                            const Color(0xFFFFF6EB),
                            const Color(0xFFFFF6D9),
                            const Color(0xFFEFFFF7),
                            const Color(0xFFF3F8FF),
                          ];
                          int colorIndex = task.id.hashCode.abs() % cardColors.length;
                          if (index > 0) {
                            int prevColorIndex = tasks[index - 1].id.hashCode.abs() % cardColors.length;
                            if (colorIndex == prevColorIndex) {
                              colorIndex = (colorIndex + 1) % cardColors.length;
                            }
                          }
                          return Card(
                            color: cardColors[colorIndex],
                            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                            elevation: 0,
                            child: ListTile(
                              title: Text(
                                task.title,
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                              subtitle: Text(
                                task.description,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              trailing: Container(
                                padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  task.status,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: task.status == 'Completed'
                                        ? Colors.green
                                        : task.status == 'Overdue'
                                            ? Colors.red
                                            : Colors.orange,
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
            ],
          );
        },
      ),
    );
  }
}
