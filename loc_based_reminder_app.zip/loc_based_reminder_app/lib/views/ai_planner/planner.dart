import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PlannerScreen extends StatefulWidget {
  const PlannerScreen({super.key});

  @override
  _PlannerScreenState createState() => _PlannerScreenState();
}

class _PlannerScreenState extends State<PlannerScreen> {
  final TextEditingController taskController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  List<Map<String, dynamic>> chatHistory = [];
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadChatHistory();
  }

  Future<void> _loadChatHistory() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    final snapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('planner_chats')
        .orderBy('timestamp')
        .get();
    setState(() {
      chatHistory = snapshot.docs.map((doc) => doc.data()).toList();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
  }

  Future<void> _saveMessage(String sender, String message) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    final msg = {
      'sender': sender,
      'message': message,
      'timestamp': FieldValue.serverTimestamp(),
    };
    await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('planner_chats')
        .add(msg);
  }

  Future<void> fetchPlanSuggestions(String input) async {
    setState(() => isLoading = true);
    await _saveMessage('user', input);
    setState(() {
      chatHistory.add({'sender': 'user', 'message': input, 'timestamp': DateTime.now()});
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());

    const String apiKey = 'AIzaSyDaoJTLReh44nNUAKHv7Ha5lPuNTwYBUGg';
    const String apiUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {
          'Content-Type': 'application/json',
          'X-goog-api-key': apiKey,
        },
        body: jsonEncode({
          "contents": [
            {
              "parts": [
                {"text": input}
              ]
            }
          ]
        }),
      );

      String reply = '';
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['candidates'] != null &&
            data['candidates'].isNotEmpty &&
            data['candidates'][0]['content'] != null &&
            data['candidates'][0]['content']['parts'] != null &&
            data['candidates'][0]['content']['parts'][0]['text'] != null) {
          reply = data['candidates'][0]['content']['parts'][0]['text'];
        } else {
          reply = 'No response from Gemini.';
        }
      } else {
        reply = "Error: ${response.reasonPhrase}";
      }
      await _saveMessage('ai', reply);
      setState(() {
        chatHistory.add({'sender': 'ai', 'message': reply, 'timestamp': DateTime.now()});
        isLoading = false;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    } catch (e) {
      setState(() {
        chatHistory.add({'sender': 'ai', 'message': 'An error occurred. Please try again.', 'timestamp': DateTime.now()});
        isLoading = false;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 249, 221, 250),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const SizedBox(height: 32,),
            const Text(
              "What would you like to do about today?",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w900, 
                fontFamily: 'Poppins', 
                color: Color.fromARGB(255, 119, 118, 118),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                itemCount: chatHistory.length + (isLoading ? 1 : 0),
                itemBuilder: (context, index) {
                  if (isLoading && index == chatHistory.length) {
                    return Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: TypingIndicator(),
                      ),
                    );
                  }
                  final msg = chatHistory[index];
                  final isUser = msg['sender'] == 'user';
                  return Align(
                    alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                      decoration: BoxDecoration(
                        color: isUser ? const Color(0xFFFFE9DE) : Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Text(
                        msg['message'] ?? '',
                        style: TextStyle(
                          color: Colors.black,
                          fontFamily: 'Poppins',
                          fontWeight: isUser ? FontWeight.bold : FontWeight.normal,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            SizedBox(
              height: 56,
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: taskController,
                      textAlign: TextAlign.left,
                      textAlignVertical: TextAlignVertical.center,
                      decoration: InputDecoration(
                        hintText: 'Describe your day or tasks...',
                        hintStyle: const TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                        ),
                        fillColor: Colors.white,
                        filled: true,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 0, // Center the hint vertically
                        ),
                      ),
                      style: const TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w900,
                      ),
                      maxLines: 1,
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: isLoading
                        ? null
                        : () {
                            if (taskController.text.trim().isNotEmpty) {
                              fetchPlanSuggestions(taskController.text.trim());
                              taskController.clear();
                            }
                          },
                    child: Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 249, 209, 222),
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Center(
                        child: Image.asset('assets/icons/Send 01.png',width: 26,height: 26,),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TypingIndicator extends StatefulWidget {
  const TypingIndicator({super.key});

  @override
  _TypingIndicatorState createState() => _TypingIndicatorState();
}

class _TypingIndicatorState extends State<TypingIndicator> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<int> _dotCount;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 900),
      vsync: this,
    )..repeat();
    _dotCount = StepTween(begin: 1, end: 3).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _dotCount,
      builder: (context, child) {
        String dots = '.' * _dotCount.value;
        return Text(
          'AI is typing$dots',
          style: const TextStyle(
            color: Colors.black54,
            fontFamily: 'Poppins',
            fontStyle: FontStyle.italic,
            fontSize: 16,
          ),
        );
      },
    );
  }
}


