import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:loc_based_reminder_app/main.dart';
import 'package:loc_based_reminder_app/views/calender/calender_data.dart';
import 'package:loc_based_reminder_app/views/profile/profile_screen.dart';
import 'views/add_task/add_task.dart';
import 'views/ai_planner/planner.dart';
import 'views/homescreen/home.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:async';
import 'package:geolocator/geolocator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';

class NavigationMenu extends StatefulWidget {
  const NavigationMenu({super.key});

  @override
  _NavigationMenuState createState() => _NavigationMenuState();
}

class _NavigationMenuState extends State<NavigationMenu> {
  int _selectedIndex = 0;
  Timer? _locationTimer;
  Timer? _notificationTimer;
  final Set<String> _notifiedTaskIds = {};

  @override
  void initState() {
    super.initState();
    _askPermissionsAndStartLocationUpdates();
    _requestNotificationPermission();
    _startPeriodicTaskNotificationChecker();
  }

  Future<void> _requestNotificationPermission() async {
    await flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  Future<void> _askPermissionsAndStartLocationUpdates() async {
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      await showDialog( 
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog( 
          title: const Text('Location Permission Required'),
          content: const Text('This app needs location permission to function properly.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      // Try again
      return _askPermissionsAndStartLocationUpdates();
    }

    // // Request background location permission if needed
    // if (permission == LocationPermission.whileInUse) {
    //   permission = await Geolocator.requestPermission();
    //   if (permission != LocationPermission.always) {
    //     await showDialog(
    //       context: context,
    //       barrierDismissible: false,
    //       builder: (context) => AlertDialog(
    //         title: const Text('Background Location Required'),
    //         content: const Text('This app needs background location permission to update your location in the background.'),
    //         actions: [
    //           TextButton(
    //             onPressed: () => Navigator.of(context).pop(),
    //             child: const Text('OK'),
    //           ),
    //         ],
    //       ),
    //     );
    //     return _askPermissionsAndStartLocationUpdates();
    //   }
    // }

    if (Platform.isAndroid) {
      final sdkInt = (await DeviceInfoPlugin().androidInfo).version.sdkInt;
      if (sdkInt >= 33) {
        await FirebaseMessaging.instance.requestPermission();
      }
    }

    _startLocationUpdates();
  }

  void _startLocationUpdates() {
    _locationTimer?.cancel();
    _locationTimer = Timer.periodic(const Duration(seconds: 15), (_) async {
      await _updateCurrentLocation();
    });
    _updateCurrentLocation();
  }

  Future<void> _updateCurrentLocation() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    try {
      final position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      await FirebaseFirestore.instance.collection('users').doc(user.uid).update({
        'currentLocation': {
          'lat': position.latitude,
          'lng': position.longitude,
        }
      });
    } catch (e) {
      
    }
  }

  void _startPeriodicTaskNotificationChecker() {
    _notificationTimer?.cancel();

    final now = DateTime.now();
    final int secondsToNextMinute = 60 - now.second;
    Future.delayed(Duration(seconds: secondsToNextMinute), () {
      _notificationTimer = Timer.periodic(const Duration(seconds: 10), (_) async {
        await _checkTasksForNotification();
      });
      _checkTasksForNotification();
    });
  }

  Future<void> _checkTasksForNotification() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      print('[NotificationChecker] No user logged in.');
      return;
    }
    final now = DateTime.now();
    final todayStr = "${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}";
    final currentTimeStr = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}";
    print('[NotificationChecker] Checking tasks at $todayStr $currentTimeStr');
    final snapshot = await FirebaseFirestore.instance
        .collection('tasks')
        .where('userId', isEqualTo: user.uid)
        .get();

    // Get current location once for all tasks
    Position? currentPosition;
    try {
      currentPosition = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    } catch (e) {
      print('[NotificationChecker] Could not get current location: $e');
    }

    for (final doc in snapshot.docs) {
      final data = doc.data();
      final taskId = doc.id;
      final date = data['date'] as String?;
      final time24h = data['notificationTime24h'] as String?;
      final status = (data['status'] ?? '').toString().toLowerCase();
      final location = data['location'] as Map<String, dynamic>?;
      print('[NotificationChecker] Task $taskId: date=$date, time24h=$time24h, status=$status, alreadyNotified=${_notifiedTaskIds.contains(taskId)}, location=$location');

      // Time-based notification (existing logic)
      if (date == todayStr && time24h == currentTimeStr &&
          (status == 'to do' || status == 'pending') &&
          !_notifiedTaskIds.contains(taskId)) {
        final title = data['title'] ?? 'Task Reminder';
        final desc = data['description'] ?? 'You have a pending task.';
        print('[NotificationChecker] Triggering notification for task $taskId: $title (time match)');
        flutterLocalNotificationsPlugin.show(
          taskId.hashCode,
          'Task Reminder',
          '$title: $desc',
          const NotificationDetails(
            android: AndroidNotificationDetails(
              'task_channel',
              'Task Reminders',
              channelDescription: 'Reminders for your scheduled tasks',
              importance: Importance.max,
              priority: Priority.high,
            ),
          ),
        );
        _notifiedTaskIds.add(taskId);
      }

      // Location-based notification
      if (date == todayStr &&
          location != null &&
          location['lat'] != null && location['lng'] != null &&
          currentPosition != null &&
          (status == 'to do' || status == 'pending') &&
          !_notifiedTaskIds.contains('loc_$taskId')) {
        final double taskLat = (location['lat'] as num).toDouble();
        final double taskLng = (location['lng'] as num).toDouble();
        final double distance = Geolocator.distanceBetween(
          currentPosition.latitude,
          currentPosition.longitude,
          taskLat,
          taskLng,
        );
        print('[NotificationChecker] Task $taskId: distance to task location = $distance meters');
        if (distance < 1000) {
          final title = data['title'] ?? 'Task Location Reminder';
          final desc = data['description'] ?? 'You are near your task location.';
          print('[NotificationChecker] Triggering location-based notification for task $taskId: $title');
          flutterLocalNotificationsPlugin.show(
            ('loc_$taskId').hashCode,
            'Task Location Reminder',
            '$title: $desc',
            const NotificationDetails(
              android: AndroidNotificationDetails(
                'task_channel',
                'Task Reminders',
                channelDescription: 'Reminders for your scheduled tasks',
                importance: Importance.max,
                priority: Priority.high,
              ),
            ),
          );
          _notifiedTaskIds.add('loc_$taskId');
        }
      }
    }
  }

  @override
  void dispose() {
    _locationTimer?.cancel();
    _notificationTimer?.cancel();
    super.dispose();
  }

  final List<Widget> _screens = [
    const HomeScreen(),
    const CalendarDataScreen(),
    const AddTaskScreen(),
    const PlannerScreen(),
    const ProfileScreen0(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    const Color selectedColor = Color(0xFFFFE9DE);
    final List<Widget> items = [
      _buildNavIcon(FontAwesomeIcons.house, 0, selectedColor),
      _buildNavIcon(FontAwesomeIcons.calendarDays, 1, selectedColor),
      _buildNavIcon(FontAwesomeIcons.circlePlus, 2, selectedColor),
      _buildNavIcon(FontAwesomeIcons.clipboardList, 3, selectedColor),
      _buildProfileIcon(4, selectedColor),
    ];

    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: Container(
        padding: const EdgeInsets.only(top: 10, bottom: 28),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(items.length, (index) => items[index]),
        ),
      ),
    );
  }

  Widget _buildNavIcon(IconData icon, int index, Color selectedColor) {
    final bool isSelected = _selectedIndex == index;
    return SizedBox(
      width: 56,
      height: 56,
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: () => _onItemTapped(index),
        child: Center(
          child: Container(
            width: 44,
            height: 44,
            decoration: isSelected
                ? BoxDecoration(
                    color: selectedColor,
                    shape: BoxShape.circle,
                  )
                : null,
            child: Center(
              child: FaIcon(
                icon,
                color: Colors.black,
                size: 20,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfileIcon(int index, Color selectedColor) {
    final bool isSelected = _selectedIndex == index;
    return SizedBox(
      width: 56,
      height: 56,
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: () => _onItemTapped(index),
        child: Center(
          child: Container(
            width: 44,
            height: 44,
            decoration: isSelected
                ? BoxDecoration(
                    color: selectedColor,
                    shape: BoxShape.circle,
                  )
                : null,
            child: Center(
              child: ClipOval(
                child: Image.asset(
                  "assets/images/profile_img.jpg",
                  width: 20,
                  height: 20,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
