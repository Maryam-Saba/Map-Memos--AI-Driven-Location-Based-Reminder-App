package com.example.loc_based_reminder

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
